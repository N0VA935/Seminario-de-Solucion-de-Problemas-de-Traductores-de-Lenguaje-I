/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;

/**
 *
 * @author José David Delgado Ramírez
 */
public class analizadorOperando {
    public static String RESULT;
    public static String BTD;

    public static String getBTD() {
        return BTD;
    }

    public static void setBTD(String BTD) {
        analizadorOperando.BTD = BTD;
    }

    public static String getRESULT() {
        return RESULT;
    }

    public static void setRESULT(String RESULT) {
        analizadorOperando.RESULT = RESULT;
    }
    /**
     * Funcion para revisar que los operandos se encuentren en el orden correspondiente
     * a cada modo de direccionamiento
     * @param indexInitial -Indice del codigo de operacion de TABOP para saber
     * a que modo de direccionamiento pertenece el operando del mismo.
     * @param operando -Operando a analizar del TXT original de instrucciones
     */
    public static boolean opChecker(int indexInitial, String operando) {
        arrayContainer ar = new arrayContainer();
        // Variables de analizado
        String addMode = ar.getTABOP().get(indexInitial);
        String revisado = "";
        boolean result = false;
            switch(addMode){
                case "Inmediato":   // Modo de direccionamiento Inmediato
                    if(operando.startsWith("#")) {
                        revisado = baseToDecimal(operando.substring(1), operando.substring(1, 2));
                        if(Integer.parseInt(revisado) < 0 || Integer.parseInt(revisado) > 65535) {
                            setRESULT("Error en Inmediato");
                            result = false;
                        } else {
                            setRESULT(revisado + " de tipo inmediato " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                            result = true;
                        }
                    }
                    break;
                case "Directo": // Modo de direccionamiento Directo
                    if(!operando.contains(",")){
                        revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));
                        if(revisado.equals("Error"))  {
                            setRESULT("Error en directo");
                            result = false;
                        }else
                            if( Integer.parseInt(revisado) > 0 && Integer.parseInt(revisado) < 256) {
                                setRESULT(revisado + " de tipo directo " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                                result = true;
                            }
                    }
                    break;
                case "Extendido":   // Modo de direccionamiento  Extendido
                    if(operando.matches("^\\p{Alpha}*\\w*") &&  operando.length() <= 8) {  // Condicional para etiquetas
                        setRESULT(operando + " de tipo extendido " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                        result = true;
                    } else {
                        if(!operando.contains(",")){
                            revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));                            
                            if(revisado.equals("Error") || Integer.parseInt(revisado) > 255 && Integer.parseInt(revisado) < 65535) {
                                setRESULT(revisado + " de tipo Extendido " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                                result = true;
                            }
                        }else 
                            result = false;
                    }
                    break;
                case "IDX": // Modo de direccionamiento Indexado 5 bits
                    if(operando.contains(",") && (!operando.startsWith("[") || !operando.endsWith("]"))){
                        String[] idx = operando.split(",");
                        if(Identificador.numberCheck(idx[0]) && (Integer.parseInt(idx[0]) > 0 && Integer.parseInt(idx[0]) < 9) && (operando.contains("+") || operando.contains("-"))){    // Condicional para identificar los posibles IDX si llevan un acumulador
                            for (int i = 1; i < idx.length; i++) {  // Ciclo que recorre el array en busca de acumuladores con signo
                                if(idx[i].toUpperCase().equals(pmSymbol(idx[i])+"X") || idx[i].toUpperCase().equals(pmSymbol(idx[i])+"Y") 
                                        || idx[i].toUpperCase().equals(pmSymbol(idx[i])+"SP") || idx[i].toUpperCase().equals(pmSymbol(idx[i])+"PC") 
                                        || idx[i].toUpperCase().equals("X"+pmSymbol(idx[i])) || idx[i].toUpperCase().equals("Y"+pmSymbol(idx[i])) 
                                        || idx[i].toUpperCase().equals("SP"+pmSymbol(idx[i])) || idx[i].toUpperCase().equals("PC"+pmSymbol(idx[i]))) {
                                    setRESULT(operando + " de tipo indexado acumulativo/pre/post incremento " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                                    result = true;
                                } else {
                                    setRESULT("Error en IDX");
                                    result = false;
                                }
                            }

                            break;  // Cierra el case
                        }else if(Identificador.numberCheck(idx[0]) && (Integer.parseInt(idx[0]) > -17 && Integer.parseInt(idx[0]) < 16)) {    // Si cumple las normas del IDX normal
                            for (int i = 1; i < idx.length; i++) {
                                if(idx[i].toUpperCase().equals("X") || idx[i].toUpperCase().equals("Y") || idx[i].toUpperCase().equals("SP") || idx[i].toUpperCase().equals("PC")){
                                    setRESULT(operando + " de tipo indexado de 5 bits "  + ar.getTABOP().get(indexInitial+3) + " Bytes"); // Impresion de resultado
                                    result = true;
                                }else {    // Si no imprime error
                                    setRESULT("Error en IDX");
                                    result = false;
                                }

                            }   // Fin de for
                        } else if(idx[0].isEmpty()) {   // Si en caso solo contiene el valor del acumulador
                            for (int i = 1; i < idx.length; i++) {  // Recorre que sea igual
                                if(idx[i].toUpperCase().equals("X") || idx[i].toUpperCase().equals("Y") || idx[i].toUpperCase().equals("SP") || idx[i].toUpperCase().equals("PC")) { 
                                    setRESULT(operando + " de tipo indexado de 5 bits "  + ar.getTABOP().get(indexInitial+3) + " Bytes");
                                    result = true;
                                }else {   // Si no imprime error
                                    setRESULT("Error en IDX");
                                    result = false;
                                }

                            }   // Fin de for
                        } else if(idx[0].length() <= 1 && (idx[0].toUpperCase().startsWith("A") && idx[0].toUpperCase().endsWith("A") || idx[0].toUpperCase().startsWith("B") && idx[0].toUpperCase().endsWith("B")
                                || idx[0].toUpperCase().startsWith("D") && idx[0].toUpperCase().endsWith("D"))) {    // Si solo contiene los valores de acumuladores
                            for (int i = 1; i < idx.length; i++) {
                                if(idx[i].toUpperCase().equals("X") || idx[i].toUpperCase().equals("Y") || idx[i].toUpperCase().equals("SP") || idx[i].toUpperCase().equals("PC")){ 
                                    setRESULT(operando + " de tipo indexado acumulativo "  + ar.getTABOP().get(indexInitial+3) + " Bytes"); // Imprime el resultado
                                    result = true;
                                }
                            }   // Fin de for
                        } else { // Si no imprime error
                            setRESULT("Error en IDX");
                            result = false;
                        }
                    }
                    break;
                case "IDX1":    // Modo de direccionamiento Indexado9 bits
                    if(operando.contains(",") && (!operando.startsWith("[") || !operando.endsWith("]"))) {
                        String[] idx1 = operando.split(",");
                        if(Identificador.numberCheck(idx1[0]) && (Integer.parseInt(idx1[0]) > -257 && Integer.parseInt(idx1[0]) < -18 ||
                                Integer.parseInt(idx1[0]) > 15 && Integer.parseInt(idx1[0]) < 256)) {   // Si cumple los requisitos de IDX1
                            for (int i = 1; i < idx1.length; i++) {
                                if(idx1[i].toUpperCase().matches("X") || idx1[i].toUpperCase().matches("Y") || idx1[i].toUpperCase().matches("SP") || idx1[i].toUpperCase().matches("PC")) {
                                    setRESULT(operando + " de tipo indexado de 9 bits " + ar.getTABOP().get(indexInitial+3) + " Bytes"); // Imprime los resultados
                                    result = true;
                                }else {    // Si no imprime error
                                    setRESULT("Error en IDX1");
                                    result = false;
                                }
                            }   // Fin de for
                        }
                    }
                    break;
                case "IDX2":    // Modo de direccionamiento Indexado 16 bits
                    if(operando.contains(",") && (!operando.startsWith("[") || !operando.endsWith("]"))) {
                        String[] idx2 = operando.split(",");
                        if(Identificador.numberCheck(idx2[0]) && (Integer.parseInt(idx2[0]) > 255 && Integer.parseInt(idx2[0]) < 65536)) {    // Compara si esta correcto el valor de de IDX2
                            for (int i = 1; i < idx2.length; i++) {
                                if(idx2[i].toUpperCase().equals("X") || idx2[i].toUpperCase().equals("Y") || idx2[i].toUpperCase().equals("SP") || idx2[i].toUpperCase().equals("PC")) {
                                    setRESULT(operando + " de tipo indexado 16 bits " + ar.getTABOP().get(indexInitial+3) + " Bytes"); // Imprime los resultados
                                    result = true;
                                }else {   // Si no imprime error
                                    setRESULT("Error en IDX2");
                                    result = false;
                                }
                            }
                        }
                    }
                    break;
                case "[IDX2]":  // Modo de direccionamiento Indexado Indirecto 16 bits
                    if(operando.startsWith("[") && operando.endsWith("]")) {    // Si tiene los corchetes correctamente
                        String auxiliar = operando.substring(1, operando.length()-1);   // Auxiliar para ignorar los corchetes
                        String[] idx2C = auxiliar.split(",");
                        if(Identificador.numberCheck(idx2C[0]) && (Integer.parseInt(idx2C[0]) > -1 && Integer.parseInt(idx2C[0]) < 65536)) {  // Separa por los valores
                            for (int i = 1; i < idx2C.length; i++) {
                                if(idx2C[i].toUpperCase().equals("X") || idx2C[i].toUpperCase().equals("Y") || idx2C[i].toUpperCase().equals("SP") || idx2C[i].toUpperCase().equals("PC")) {
                                    setRESULT(operando + " de tipo IDX indexado de 16 bits " + ar.getTABOP().get(indexInitial+3) + " Bytes"); // Imprime los resultados
                                    result = true;
                                }else {
                                    setRESULT("Error en [IDX2]");  // Marca error
                                    result = false;
                                }
                            }   // Fin de for
                        } else {  // Marca error
                            setRESULT("Error en [IDX2]");
                            result = false;
                        }
                    } 
                    break;
                case "[D,IDX]": // Modo de direccionamiento Indexado Acumulativo Indirecto
                    if(operando.startsWith("[") && operando.endsWith("]")) {    // Identifica los corchetes
                        String auxiliar = operando.substring(1, operando.length()-1);   // Toma solo el contenido de los corchetes
                        String[] idxD = auxiliar.split(",");
                        if(idxD[0].startsWith("D") && idxD[0].endsWith("D")) {  // Comprueba que siempre empiece por B
                            for (int i = 1; i < idxD.length; i++) {
                                if(idxD[i].toUpperCase().equals("X") || idxD[i].toUpperCase().equals("Y") || idxD[i].toUpperCase().equals("SP") || idxD[i].toUpperCase().equals("PC")) {
                                    setRESULT(operando + " de tipo IDX indexado acumulativo " + ar.getTABOP().get(indexInitial+3) + " Bytes");
                                    result = true;
                                }else {
                                    setRESULT("Error en [D,IDX]"); // Impresion de error
                                    result = false;
                                }
                            }   // Fin de for
                        } else {
                            setRESULT("Error en [D,IDX]"); // Impresion de error
                            result = false;
                        }
                    } 
                    break;
                case "REL": // Modo de direccionamiento Relativo
                    if(operando.matches("^\\p{Alpha}*\\w*")){  // Condicional para etiquetas
                        if(operando.length() <= 8) {
                            setRESULT(operando + " de tipo relativo "  + ar.getTABOP().get(indexInitial+3) + " Bytes");
                            result = true;
                        }else {
                            setRESULT("Error en REL"); // Impresion de error en etiqueta
                            result = false;
                        }
                    }
                    break;
                case "Inherente":
                    setRESULT(operando + " de tipo Inherente "  + ar.getTABOP().get(indexInitial+3) + " Bytes");
                    result = true;
                    break;
                default:    // Caso para cuando no entra en ninguno
                    setRESULT("Missing Traget!!!");    // Nunca entra en ninguno
                    break;
            }
       return result; 
    }   // Fin de metodo
    /**
     * Funcion para determinar la cantidad de bytes por las directivas empleadas
     * como CODOP, esta funcion retorna el valor debido de cada directiva
     * acorde a su tipo.
     * Retorna la cantidad de bits dependiendo en cada directica, en caso de NO
     * encontrarla envia un "Missing Target!!!", si la directiva es correcta pero
     * supera las condiciones para la misma retorna el valor de la misma pero en 
     * negativo.
     * @param directiva -Directiva a comparar entre las posibles conocidas
     * @param operando -Operando del CODOP usado para determinar si es correcto
     * o no
     */
    public static String constDirect(String directiva, String operando){
        //Variables locales
        String retByte = "";
        String revisado = "";
        // Switch para las directivas
        switch(directiva){
            case "DB":  // Directivas de constantes
            case "DC.B":
            case "FCB":
                revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));  // Metodo par identificar el tipo de dato
                if(Integer.parseInt(revisado) > -1 && Integer.parseInt(revisado) < 256) // Condicional para que no exceda un Byte
                    retByte = "1";
                else
                    retByte = "-1";
                break;
            case "DW":
            case "DC.W":
            case "FDB":
                revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));  // Metodo par identificar el tipo de dato
                if(Integer.parseInt(revisado) > -1 && Integer.parseInt(revisado) < 65536)   // Condicional para que no exceda 2 Bytes
                    retByte = "2";
                else
                    retByte = "-2";
                break;
            case "FCC":
                if(operando.startsWith("\"") && operando.endsWith("\""))    // Condicional para saber que contiene comillas dobles
                    retByte = Integer.toString(operando.length()-2);    // Devuelve el valor del estring menos las comillas
                else
                    retByte = "-" + Integer.toString(operando.length()-2);
                break;  ////////////////////
            case "DS":  // Directivas de reserva en espacio de memoria
            case "DS.B":
            case "RMB":
                revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));  // Metodo par identificar el tipo de dato
                if(Integer.parseInt(revisado) > -1 && Integer.parseInt(revisado) < 65536)   // Condicional para no exceder los dos bytes
                    retByte = Integer.toString(Integer.parseInt(revisado) * 1);
                else
                    retByte = "-" + operando;
                break;
            case "DS.W":
            case "RMW":
                revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));  // Metodo par identificar el tipo de dato
                if(Integer.parseInt(revisado) > -1 && Integer.parseInt(revisado) < 65536)   // Condicional para no exceder los dos bytes
                    retByte = Integer.toString(Integer.parseInt(revisado) * 2);
                else
                    retByte = "-" + operando;
                break;  /////////////////////
            case "EQU": // Otras directivas
                revisado = baseToDecimal(operando.substring(0), operando.substring(0, 1));  // Metodo par identificar el tipo de dato
                if(Integer.parseInt(revisado) > -1 && Integer.parseInt(revisado) < 65536)   // Condicional para no exceder los dos bytes
                    retByte = revisado;
                else
                    retByte = "-" + revisado;
                break;  ////////////////////
            default:    // Caso para cuando no es ninguna
                System.out.println("Missing Target!!!");
                break;
        }   // Fin de switch
        return retByte; // Retorno de resultado
    }   // Fin de funcion
    /**
     * Funcion booleana para retornar en funcion de un diccionario de 
     * las direcctivas para si encuentra alguna, retorna true si encontro una
     * false si no encontro ninguna parecida.
     * @param directiva -Directiva usada para buscar en el indice
     */
    public static boolean constDirect(String directiva){
        
        // Switch para las directivas
        switch(directiva){
            case "DB":  // Directivas de constantes
            case "DC.B":
            case "FCB":
                return true;
            case "DW":
            case "DC.W":
            case "FDB":
                return true;
            case "FCC":
                return true;  ////////////////////
            case "DS":  // Directivas de reserva en espacio de memoria
            case "DS.B":
            case "RMB":
                return true;
            case "DS.W":
            case "RMW":
                return true;  /////////////////////
            case "EQU": // Otras directivas
                return true;  ////////////////////
            default:    // Caso para cuando no es ninguna
                return false;
        }   // Fin de switch
    }   // Fin de funcion
    
    /**
     * Funcion para retornar el valor en decimal de cualquier numero dependiendo
     * de su base.
     * @param numero -Numero a evaluar para que este sea retornado a una base 
     * de tipo decimal.
     * @param base -Base del numero que se implementara acorde a su tipo.
     * @return 
     */
    public static String baseToDecimal(String numero, String base){
        int numDecimal;
        String result;
        if(Identificador.numberCheck(base)){
            base = "number";
        }
        switch(base){
            case "$":   // Caso para transformar a hex-decimal
                numDecimal = Integer.parseInt(numero.substring(1), 16);
                result = Integer.toString(numDecimal);
                break;
            case "@":   // Caso para transformar octal-decimal
                numDecimal = Integer.parseInt(numero.substring(1), 8);
                result = Integer.toString(numDecimal);
                break;
            case "%":   // Caso para transformar binario-decimal
                numDecimal = Integer.parseInt(numero.substring(1), 2);
                result = Integer.toString(numDecimal);
                break;
            case "number":
                numDecimal = Integer.parseInt(numero);
                result = Integer.toString(numDecimal);
                break;
            default:    // Caso para cuando es solo decimal
                result = "Error";
                break;
        }
        setBTD(result);
        return result;
    }
    /**
     * Funcion que retornar si se empieza o termina con un signo
     * positivo o negativo de una parte especifica del operando
     * para cuando su modo de direccion es Indexado acumulativo/pre/post
     * incremento.
     * @param acumulador -Variable acumador que reserva el aacumulador del 
     * operando.
     */
    private static String pmSymbol(String acumulador) {
        String simbolo; // Variable que almacena el numero
        if(acumulador.startsWith("+") || acumulador.endsWith("+"))  // Si empieza o termina en +
            simbolo = "+";  // Da el valor del signo
        else if(acumulador.startsWith("-") || acumulador.endsWith("-")) // Si empieza o termina en +
            simbolo = "-";  // Da el valor del signo
        else    // Sino envia directamente un error
            simbolo = "Error 404";
        return simbolo; // Devuelve el valor final
    }   // Fin de funcion
}
