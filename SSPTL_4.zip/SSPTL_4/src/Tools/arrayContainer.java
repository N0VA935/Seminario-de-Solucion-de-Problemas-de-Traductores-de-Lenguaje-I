/**
 * Delgado Ramírez, José David
 * Franco García, Hugo Israel
 * arrayContainer.java
 * 28/09/2020
 * Descripcion:
 * En base a un txt se compara el CODOP contra el TABOP para encontrar las relaciones
 * y los datos que se asocian a este, y ademas permite buscar los operandos
 * correspondientes.
 */
package Tools;

import java.util.ArrayList;

/**
 *
 * @author José David Delgado Ramírez
 * @author Hugo Israel Franco García
 */
public class arrayContainer {
    // Creacion de arraylist para cargar las isntrucciones
    private static ArrayList<String> INST = new ArrayList<String>();
    private static ArrayList<String> TABOP = new ArrayList<String>();
    private static ArrayList<String> RESULT = new ArrayList<String>();
    private static ArrayList<String> IMPBYTES = new ArrayList<String>();
    /**
     * Funcion para retornar la cantidad de Bytes correspondientes
     */
    public ArrayList<String> getIMPBYTES() {
        return IMPBYTES;
    }   // Fin de funcion
    /**
     * Metodo para dar el valor a la cantidad de bytes
     * @param IMPBYTES -Cantidad de bytes a ingresar
     */
    public static void setIMPBYTES(ArrayList<String> IMPBYTES) {
        arrayContainer.IMPBYTES = IMPBYTES;
    }   // Fin de metodo
    /**
     * Funcion para retornar la arrayList con el resultado final
     */
    public ArrayList<String> getRESULT() {
        return RESULT;
    }   // Fin de funcion
    
    /**
     * Funcion para retornar la arrayList con el conjunto de instrucciones
     */
    public ArrayList<String> getINST() {
        return INST;
    }   // Fin de funcion
    
    /**
     * Funcion para dar los valores a la arraylist
     * @param INST -Arraylist con el conjunto de instrucciones
     */
    public static void setINST(ArrayList<String> INST) {
        arrayContainer.INST = INST;
    }   // Fin de metodo
    
    /**
     * Metodo para retornar la arrayList con el TABOP
     */
    public ArrayList<String> getTABOP() {
        return TABOP;
    }   // Fin de metodo
    /**
     * Funcion para dar el valor a la arraylist del Tabop
     * @param TABOP -Carga de insrtrucciones en el TABOP
     */
    public static void setTABOP(ArrayList<String> TABOP) {
        arrayContainer.TABOP = TABOP;
    }   // Fin de funcion
    /**
     * Funcion para buscar los valores que se encuentran relacionados directamente
     * con el TABOP y añade solo los encontrados
     */
    public void finder(){
        // Ciclo for para recorrer el set de instrucciones principales
        for (int i = 0; i < INST.size(); i++) {
            boolean paso = false;   // Variable para reconocer el final
            //IMPBYTES.add(" Operando convertido= "+analizadorOperando.opChecker(8, "#3"));
            if(INST.get(i).startsWith("OPERANDO=")) {  // Si contiene el identificador
                String[] tOper = INST.get(i).split("= ");  // Realiza un split a partir de ese punto
                // for para hacer el recorrido del TABOP
                for (int j = 0; j < TABOP.size(); j+=6) {
                    String[] tCODOP = INST.get(i-1).split("= ");
                    if(tCODOP[1].toUpperCase().equals(TABOP.get(j))) {
                        paso=true;
                        if(!correct(j, i)){   // Condicional para detectar la funcion
                            break;  // Rompe el ciclo
                        }else { // Si no
                            for (int k = j; k < (j+5); k++) {
                                RESULT.add(TABOP.get(k));
                            }
                            if(analizadorOperando.opChecker(j+2, tOper[1]) != false){
                                if(!INST.get(i-2).contains("NULL") && (i > 1)) {
                                    //System.out.println("Operando " + INST.get(i).substring(9) + " Base " +INST.get(i).substring(10));
                                    IMPBYTES.add("¨" + (TABOP.get(j+5)) + "&" + (TABOP.get(j+5))
                                    +"°" + INST.get(i-2).substring(10) + "°" + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));
                                    break;
                                }else{
                                    IMPBYTES.add("&" + (TABOP.get(j+5)) + "°" + INST.get(i-2).substring(10) + "°" + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));
                                    break;
                                }
                            }
                        }   // Fin de else
                    }else if(analizadorOperando.constDirect(tCODOP[1].toUpperCase())){
                        if(!INST.get(i-2).contains("ETIQUETA= NULL") && i > 1){ // Si no contiene el valor NULL y es desde la posicion 1
                            if(tCODOP[1].toUpperCase().equals("EQU")) {   // Si el codop es EQU
                                IMPBYTES.add("¨" + analizadorOperando.baseToDecimal(INST.get(i).substring(10), INST.get(i).substring(10,11)) + "^" + analizadorOperando.constDirect(tCODOP[1], tOper[1]) + "°" + INST.get(i-2).substring(10) + "°"
                                + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));  // Da con un simbolo especial para identificar la etiqueta y el codigo EQU
                            } else {
                                IMPBYTES.add("¨" + analizadorOperando.baseToDecimal(INST.get(i).substring(10), INST.get(i).substring(10,11)) + "&"+analizadorOperando.constDirect(tCODOP[1], tOper[1]) + "°" + INST.get(i-2).substring(10) + "°"
                                + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));    // Da con un simbolo especial para identificar la etiqueta y el codigo CODOP
                            }
                            break;  // Sale del ciclo
                        } else if(i > 1){
                                IMPBYTES.add("&"+analizadorOperando.constDirect(tCODOP[1], tOper[1]) + "°" + INST.get(i-2).substring(10) + "°"
                                + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));
                            break;
                        }
                        
                    }else if(tCODOP[1].toUpperCase().equals("ORG") && INST.get(i-2).contains("NULL") && i > 1){
                        IMPBYTES.add("~"+analizadorOperando.baseToDecimal(tOper[1].substring(0), tOper[1].substring(0, 1)) + "°" + INST.get(i-2).substring(10) + "°"
                                + INST.get(i-1).substring(7) + "°" + INST.get(i).substring(10));
                        break;
                    }else if(j==TABOP.size()-1 && paso != true){ // Si no da con ninguno
                        RESULT.add("Error de CODOP!!!");
                        break;
                   }// Fin de else
                }   // Fin de for de TABOP
            }   // Fin de if CODOP
        }   // Fin de for de instruccion principal
    }   // Fin de metodo
    /**
     * Funcion booleana que indica si se encuentra una irregularidad en el operando, 
     * devuelve false si se encuentra con alguna
     * @param i -Pivote para la lista de partida del TABOP
     * @param index -Indice de donde comienza a leer
     */
    public static boolean correct(int index, int i){
        boolean check = true;
        String[] tOperando = INST.get(i).split("= ");   // Separa apartir de
                // Ciclo for para recorrer solo con los que tienen operando de cada CODOP
                for (int j = 1; j < TABOP.size(); j+=6) {
                    
                    if(!tOperando[1].contains("NULL") && TABOP.get(index+1).startsWith("No Operando")) {   // Entro en el que cuando no lleva, tiene operando
                        System.out.println("Entro en el que cuando no lleva, tiene operando " + index);
                        check= false;
                        break;  // Sale del ciclo for del tabop
                    } else if(tOperando[1].contains("NULL") && TABOP.get(index+1).startsWith("Operando")) {   // Si no Entro en el que cuando no lleva, tiene operando
                        System.out.println("Entro en el que cuando lleva, no tiene operando " + index);
                        check=false;
                        break;  // Cierre del ciclo for de tabop
                    }   // Fin de else
                }   // Fin de for Tabop
                return check;
    }
}   // Fin de clase
