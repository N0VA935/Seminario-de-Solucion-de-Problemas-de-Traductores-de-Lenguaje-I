/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;
import java.util.ArrayList;


/**
 *
 * @author Jose David Delgado Ramirez
 */

/*Clase Contador*/
public class Contador 
{
    //Atributos
    private int acum;
    private int limit;
    private ArrayList<Integer> skips = new ArrayList<Integer>();
    
    //Constructores
    /** Cosntructor para crear el objeto contador */
    public Contador()
    {
        this.acum = 0;
        this.limit = 0;
    }//Fin de constructor 1
    
    /** Cosntructor para crear el objeto contador con un valor inicial */
    public Contador(int valor)
    {
        this.acum = valor;
        this.limit = 0;
    }//Fin de constructor 2
    
    /** Cosntructor para crear el objeto contador con un inicio y un límite */
    public Contador(int valor, int limite)
    {
        this.acum = valor;
        this.limit = 0;
    }//Fin de constructor 3
    /**Funcion para dar valor inicial al contador si ya se construyo el objeto*/
    public int setCount(int valor){
        return this.acum = valor;
    }
    //Metodos de comunicación
    /** Incrementa a 1 el contador */
    public void addCount()
    {
        this.acum++;
    }//Fin de addCount
    /** Incremento del contador en x al contador */
    public void addCount(int valor)
    {
        this.acum+=valor;
    }//Fin de addCount en aumento de x
    /**Funcion para decir si esta dentro o no*/
    public boolean skipTravel(int valor){
        for (int i = 0; i < skips.size(); i++) {
            if(skips.get(i) == valor) {
                return true;
            }
        }
        return false;
    }   // Fin de funcion
     /** Decrementa a 1 el contador */
    public void decCount()
    {
        this.acum--;
    }//Fin de decCount
     /** ecrementa a x el contador */
    public void decCount(int valor)
    {
        this.acum-=valor;
    }//Fin de addCount
    /**Metodo para dar un valor en la lista para saltear*/
    public void skipCount(int valor) {
        this.skips.add(valor);
    }   // Fin de metodo
    /** Funcion para retornar los saltos */
    public ArrayList<Integer> retSkips() {
        return this.skips;
    }
    /** Metodo para mostrar el valor de contador */
    public int showCount()
    {
        return this.acum;
    }//fin de mostrar valor
    /** Metodo para poner limite */
    public void setLimit(int valor)
    {
        this.limit = valor;
    }//Fin de poner limite
    /** Metodo para mostrar el limite */
    public int showLimit()
    {
        return this.limit;
    }//fin de mostrar limite
    /** Metodo para reiniciar  */
    public void resetCount()
    {
        this.acum = 0;
    }//Fin de reinicio
    
}
