
package Tools;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author José David Delgado Ramírez
 */
public class machineCode{
    public void machineCodeCalculator(String directionTEMP, String directionTABSIM) throws FileNotFoundException,IOException{
        /** Creacion de objetos */
        FileReader fr = new FileReader(directionTEMP);
        BufferedReader br = new BufferedReader(fr);
        arrayContainer ar = new arrayContainer();
        analizadorOperando ap = new analizadorOperando();
        ArrayList<String> contadorLocalidades = new ArrayList<String>();
        //////////////////////////////////////////
        //Variables
        String reader = "";
        while((reader = br.readLine())!=null){  // ciclo while para analizar las lines del temporal
            String spaces[] = reader.split("\t");   // Separacion por tabuladores de las distintas secciones
            String ContLoc = spaces[1];
            contadorLocalidades.add(spaces[1]);
            if(spaces[2].equals("END")) {   // si se llega al END
                System.out.println(spaces[2]);  // Impresion del final
            } else {    // TODO CODE HERE
                String  Etq = spaces[2], codop = spaces[3], opera = spaces[4];  // Distintas variables para la separacion de las partes del temporal
                for (int i = 0; i < ar.getTABOP().size(); i+=6) {   // Ciclo for para recorrer el for precargado
                    if(codop.equals(ar.getTABOP().get(i))) {    // Si se encuentra el CODOP dentro del for
                        if(analizadorOperando.opChecker(i+2, opera) != false) { // Condicional para verificar que cumpe los aspectos dependiendo del tipo que es
                            switch(ar.getTABOP().get(i+2)) {    // Switch para cada caso
                                case "Inherente ":  // Caso de Inherentes
                                    String INH = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3); // Obtencion del codigo maquina
                                    ar.getmCode().add(INH); // Append del codigo maquina en el arraylist 
                                    break;  // Salida
                                case "Directo": // Caso directo
                                    String DIR = "CODOP: " + ar.getTABOP().get(i) + ar.getTABOP().get(i+3) + analizadorOperando.baseToDecimal(opera.substring(1), opera.substring(0,1));    // Obtencion del codigo maquina
                                    ar.getmCode().add(DIR); // Append del codigo maquina
                                    break;  // Salida del caso
                                case "Extendido":   // Caso extendido
                                    /** Creacion de objetos para el TABSIM */
                                    FileReader frTABSIM = new FileReader(directionTABSIM);
                                    BufferedReader brTABSIM = new BufferedReader(frTABSIM);
                                    ///////////////////////////////////////////////////////
                                    // Variables
                                    String tabsimReader = "";
                                    while((tabsimReader = brTABSIM.readLine()) != null ) {   // Ciclo while para recorrer las partes del TABSIM
                                        if(!tabsimReader.equals("TABSIM no generado :)")){
                                            break;
                                        } else {
                                            String tabsimSpaces[] = tabsimReader.split("\t");   // Separacion mediante tabuladores
                                            String tipo = tabsimSpaces[0], etqTabsim = tabsimSpaces[1], conlocTabsim = tabsimSpaces[2]; // Variables de las partes del TABSIM
                                            if(etqTabsim.equals(opera)) {    // Si el operando es igual a un elemento del tabsim
                                                String EXT = ar.getTABOP().get(i+3) + conlocTabsim; // Valor del codigo maquina segun el COntloc
                                                ar.getmCode().add(EXT); // Append del codigo maquina
                                            }else { // Si no lo es
                                                String EXT = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)))).toUpperCase());   // Obtencion del codigo maquina
                                                ar.getmCode().add(EXT); // Append del codigo maquina
                                            }
                                        }
                                    }   // Fin de while
                                    brTABSIM.close();   // Cierre de TABSIM
                                    break;  // Salida del caso
                                case "Inmediato":   // Caso Inmediato
                                    String INM = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(1), opera.substring(1,2)))).toUpperCase());    // Obtencion del codigo maquina
                                    ar.getmCode().add(INM); // Append del codigo maquina
                                    break;  // Salida del caso
                                case "IDX": // Caso IDX
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep[] = opera.split(",");
                                        if(sep[0].isEmpty())
                                            sep[0] = "0";
                                        if(sep[0].equals("A") || sep[0].equals("B") || sep[0].equals("D")) {
                                            System.out.println("Hex " + Integer.toHexString(Integer.parseInt("111" + doubleRR(sep[1]) + "1" + aPosition(sep[0]),2)));
                                            String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt("111" + doubleRR(sep[1]) + "1" + aPosition(sep[0]),2)).toUpperCase());
                                            ar.getmCode().add(IDX);
                                        }
                                        else if(Integer.parseInt(sep[0]) < 16 && Integer.parseInt(sep[0]) > -17) {
                                            if(sep[1].startsWith("+") || sep[1].startsWith("-") || sep[1].endsWith("+") || sep[1].endsWith("-")) {
                                                if(Integer.parseInt(sep[0]) > 0 && Integer.parseInt(sep[0]) <  9){
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn -= 1;
                                                    sep[0] = four2Complete(Integer.toBinaryString(nnnn));
                                                    String finalis = (doubleRR(sep[1]) + "1" + pPosition(sep[1]) + sep[0]);
                                                    System.out.println("Finalis " + finalis);
                                                    System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + " " + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add(IDX);
                                                } else {
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn = Math.abs(nnnn);
                                                    nnnn -= 2;
                                                    nnnn = ~nnnn;
                                                    sep[0] = Integer.toBinaryString(nnnn);
                                                    String finalis = (doubleRR(sep[1]) + "1" + pPosition(sep[1]) + sep[0].substring(28));
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add(IDX);
                                                }
                                            } else {
                                                if(Integer.parseInt(sep[0]) > 0) {
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    sep[0] = four2Complete(Integer.toBinaryString(nnnn));
                                                    String finalis = (doubleRR(sep[1]) + "0" + sep[0]);
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add(IDX);
                                                } else if(Integer.parseInt(sep[0]) == 0){
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(sep[0])));
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(sep[0])).toUpperCase());
                                                    ar.getmCode().add(IDX);
                                                }else {
                                                    System.out.println("ESE");
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn = Math.abs(nnnn);
                                                    nnnn -= 1;
                                                    nnnn = ~nnnn;
                                                    sep[0] = Integer.toBinaryString(nnnn);
                                                    String finalis = (doubleRR(sep[1]) + "0" + sep[0].substring(27));
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add(IDX);
                                                }
                                            }
                                        }
                                    }
                                    break;
                                case "IDX1":
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep3[] = opera.split(",");
                                        if(sep3[0].isEmpty())
                                            sep3[0] = "0";
                                        if(Integer.parseInt(sep3[0]) > -16 && Integer.parseInt(sep3[0]) < 17) {}
                                        else{
                                                if(Integer.parseInt(sep3[0]) < 0) {
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep3[0], sep3[0]))).toUpperCase();
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt("111" + doubleRR(sep3[1]) + "000", 2)).toUpperCase() + temporal.substring(temporal.length()-2);
                                                    ar.getmCode().add(IDX);
                                                } else if(Integer.parseInt(sep3[0]) > 15 && Integer.parseInt(sep3[0]) < 256){
                                                    String temp = "111" + doubleRR(sep3[1]) + "000";
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep3[0], sep3[0]))).toUpperCase();
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt(temp,2)).toUpperCase() + temporal.substring(temporal.length()-2);
                                                    ar.getmCode().add(IDX);
                                                }
                                        }
                                    }
                                    break;
                                case "IDX2":
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep2[] = opera.split(",");
                                        if(sep2[0].isEmpty())
                                            sep2[0] = "0";
                                        if(Integer.parseInt(sep2[0]) < 65536 && Integer.parseInt(sep2[0]) > 255){
                                                if(Integer.parseInt(sep2[0]) < 0) {
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep2[0], sep2[0]))).toUpperCase();
                                                    String IDX = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt("111" + doubleRR(sep2[1]) + "010", 2)).toUpperCase() + temporal;
                                                    ar.getmCode().add(IDX);
                                                } else {
                                                    String temp = "111" + doubleRR(sep2[1]) + "010";
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep2[0], sep2[0]))).toUpperCase();
                                                    String IDX2 = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt(temp,2)).toUpperCase() + temporal;
                                                    ar.getmCode().add(IDX2);
                                                }
                                        } else {
                                            String IDX = "CODOP: error";
                                            ar.getmCode().add(IDX);
                                        }
                                    }
                                    break;
                                default:    // caso default
                                    //System.out.println("Missing targetaaa!!!");
                                    break;  // Salida del caso
                            }   // Fin de switch
                        }   // Fin de analizador de operando
                    }   // Fin de comparador de tabop
                }   // Fin de for para recorrer tabop
            }   // Fin de else
        }   // Fin de while de lectura del temporal
        br.close(); // Cierre de temporal
    }   // Fin de metodo
     /**
     * Funcion para retornar la cadena en formato de 
     * 4 digitos.
     * @param chain -Cadena de ingresio para dar la cantidad de 0 faltantes
     */
    private String four2Complete(String chain){
        String concat = ""; // Auxiliar de concatenacion de 0
        if(chain.length() < 5) {    // Si la cadena es menor que 4 digitos
            for (int i = chain.length(); i < 4; i++)  // For que empieza por la cantidad de caracteres de la cadena y termina cuando cumple el 4to
                concat += "0";  // Aumento de concatenacion
            return concat + chain;  // Devuelve el valor de la cadena final
        } else
            return chain;   // Si ya lo tiene solo devuelve el valor como tal
    }   // Fin de funcion
    /**
     * Funcion para retornar para cuando los valores sean menores a 5 bits
     * y de esta forma retorne el valor en un fomato de 4 digitos
     * @param chain -Cadena de entrada del texto
     */
    private String two2Complete(String chain) {
        String concat = ""; // Variable axuliar
        if(chain .length() < 2) {   // Si es menor a 2
            for (int i = chain.length(); i < 2; i++)    // Reccore y concatena
                concat += "0";
            return concat + chain;  // Devuelve el nuevo valor
        } else  // Si no es
            return chain;   // Lo devuelve igual
    }   // Fin de metodo
    /**
     * Funcion para retornar el valor de el acumulador depndiendo el tipo de este
     * retorna el valor de el acumuldar dentro de la formula
     * @param rr Parte de la formula(acumulador)
     */
    private static String doubleRR(String rr) {
        String temporal = "";
        if(rr.contains("+") || rr.contains("-")) {  // Si contiene un simbolo
            String separator[] = rr.split("\\+|\\-");   // Separa los posibles acumuladores
            for (String string : separator) {   // For iterado
                if(string.equals("X") || string.equals("Y") || string.equals("PC") || string.equals("SP")) {    // Si es algun acumulador
                    temporal = string;  // Guarda el acumulador
                    break;  // Sale
                } else  // Error
                    temporal = "Error";
            }   // Fin de for
        } else  // Si no tiene simbolos
            temporal = rr;  // Asignacion de temporal
        switch(temporal){
            case "X":
                return "00";
            case "Y":
                return "01";
            case "SP":
                return "10";
            case "PC":
                return "11";
            default:
                return "ERROR";
        }   // Fin de switch
    }   // Fin de funcion
    /**
     * Funcion para retornar el valor de p dentro de la funcion
     * @param registro -Registro que se usara para obtener el tipo de pre o post
     */
    private static String pPosition(String registro) {
        if(registro.startsWith("+") || registro.startsWith("-"))    // Si es pre
            return "0";
        else if(registro.endsWith("+") || registro.endsWith("-"))   // Si es post
            return "1";
        else
            return "Error"; // Missing case
    }   // Fin de funcion
    /**
     * Funcion para retornar el valor de un acumulador especifico
     * @param acum -Variable acumulador a cargar para retornar valor
     */
    private static String aPosition(String acum) {
        switch(acum) {  // Switch para cada funcion
            case "A":
                return "00";
            case "B":
                return "01";
            case "D":
                return "10";
            default:
                return "Error";
        }   // Fin de switch
    }   // Fin de la funcion
    
}   // Fin de clase
