
package Tools;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author José David Delgado Ramírez
 */
public class machineCode{
    private ArrayList<String> contadorLocalidades = new ArrayList<String>();
    private ArrayList<String> breakpoint = new ArrayList<String>();
    private int estoNoEsUnContador = 3;
    private int checkSum = 0;
    private String addressActual = "";
    private String longitud = "";
    // FW para el temporal
    
    FileWriter fw; 

    public machineCode() throws IOException {
        this.fw = new FileWriter("src/TXT/S19.obj");
    }
    
    public void machineCodeCalculator(String directionTEMP, String directionTABSIM) throws FileNotFoundException,IOException{
        /** Creacion de objetos */
        FileReader fr = new FileReader(directionTEMP);
        BufferedReader br = new BufferedReader(fr);
        arrayContainer ar = new arrayContainer();
        analizadorOperando ap = new analizadorOperando();
        //////////////////////////////////////////
        //Variables
        String reader = "";
        boolean inside = true;
        chargeMyTabSim(directionTABSIM);    // Carga de tabsim
        chargeTEMP(directionTEMP);  // Carga de temporal
        
        while((reader = br.readLine())!=null){  // ciclo while para analizar las lines del temporal
            //Variables
            String spaces[] = reader.split("\t");   // Separacion por tabuladores de las distintas secciones
            String ContLoc = spaces[1];
            //////////////////////////////////////////////////
            
            
            if(spaces[2].equals("END")) {   // si se llega al END
                System.out.println(spaces[2]);  // Impresion del final
            } else {    // TODO CODE HERE
                String  Etq = spaces[2], codop = spaces[3], opera = spaces[4];  // Distintas variables para la separacion de las partes del temporal
                for (int i = 0; i < ar.getTABOP().size(); i+=6) {   // Ciclo for para recorrer el for precargado
                    if(codop.equals(ar.getTABOP().get(i))) {    // Si se encuentra el CODOP dentro del for
                        if(analizadorOperando.opChecker(i+2, opera) != false) { // Condicional para verificar que cumpe los aspectos dependiendo del tipo que es
                            switch(ar.getTABOP().get(i+2)) {    // Switch para cada caso
                                
                                case "Inherente":  // Caso de Inherentes
                                    String INH = ar.getTABOP().get(i+3); // Obtencion del codigo maquina
                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+INH); // Append del codigo maquina en el arraylist 
                                    S19record(INH, spaces[1]); // Llamado del S19record
                                    break;  // Salida
                                case "Directo": // Caso directo
                                    String DIR = ar.getTABOP().get(i+3) + two2Complete(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)));    // Obtencion del codigo maquina
                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+DIR); // Append del codigo maquina
                                    S19record(DIR, spaces[1]); // Llamado del S19record
                                    break;  // Salida del caso
                                case "Extendido":   // Caso extendido
                                    int tr = Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)));
                                    if(!opera.startsWith("#") && analizadorOperando.opChecker(i+2, opera) != false && (tr > 255 && tr < 65536)) {
                                    /** Creacion de objetos para el TABSIM */
                                    FileReader frTABSIM = new FileReader(directionTABSIM);
                                    BufferedReader brTABSIM = new BufferedReader(frTABSIM);
                                    ///////////////////////////////////////////////////////
                                    // Variables
                                    String tabsimReader = "";
                                    while((tabsimReader = brTABSIM.readLine()) != null ) {   // Ciclo while para recorrer las partes del TABSIM
                                        if(tabsimReader.equals("TABSIM no generado :)")){
                                            System.out.println("operando ext: " + opera);
                                            break;
                                        } else {
                                            String tabsimSpaces[] = tabsimReader.split("\t");   // Separacion mediante tabuladores
                                            String tipo = tabsimSpaces[0], etqTabsim = tabsimSpaces[1], conlocTabsim = tabsimSpaces[2]; // Variables de las partes del TABSIM
                                            if(etqTabsim.equals(opera)) {    // Si el operando es igual a un elemento del tabsim
                                                String EXT = ar.getTABOP().get(i+3) + conlocTabsim; // Valor del codigo maquina segun el COntloc
                                                ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+EXT); // Append del codigo maquina
                                                S19record(EXT, spaces[1]); // Llamado del S19record
                                                break;
                                            }else { // Si no lo es
                                                String EXT = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)))).toUpperCase());   // Obtencion del codigo maquina
                                                ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+EXT); // Append del codigo maquina
                                                S19record(EXT, spaces[1]); // Llamado del S19record
                                                break;
                                            }
                                        }
                                    }   // Fin de while
                                    brTABSIM.close();   // Cierre de TABSIM
                                    }
                                    break;  // Salida del caso
                                case "Inmediato":   // Caso Inmediato
                                    String INM = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(1), opera.substring(1,2)))).toUpperCase());    // Obtencion del codigo maquina
                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+INM); // Append del codigo maquina
                                    S19record(INM, spaces[1]); // Llamado del S19record
                                    break;  // Salida del caso
                                case "IDX": // Caso IDX
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep[] = opera.split(",");
                                        if(sep[0].isEmpty())
                                            sep[0] = "0";
                                        if(sep[0].equals("A") || sep[0].equals("B") || sep[0].equals("D")) {
                                            String IDX = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt("111" + doubleRR(sep[1]) + "1" + aPosition(sep[0]),2)).toUpperCase());
                                            ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                            S19record(IDX, spaces[1]); // Llamado del S19record
                                        }
                                        else if(Integer.parseInt(sep[0]) < 16 && Integer.parseInt(sep[0]) > -17) {
                                            if(sep[1].startsWith("+") || sep[1].startsWith("-") || sep[1].endsWith("+") || sep[1].endsWith("-")) {
                                                if(Integer.parseInt(sep[0]) > 0 && Integer.parseInt(sep[0]) <  9){
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn -= 1;
                                                    sep[0] = four2Complete(Integer.toBinaryString(nnnn));
                                                    String finalis = (doubleRR(sep[1]) + "1" + pPosition(sep[1]) + sep[0]);
                                                    String IDX = ar.getTABOP().get(i+3) + " " + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                } else {
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn = Math.abs(nnnn);
                                                    nnnn -= 2;
                                                    nnnn = ~nnnn;
                                                    sep[0] = Integer.toBinaryString(nnnn);
                                                    String finalis = (doubleRR(sep[1]) + "1" + pPosition(sep[1]) + sep[0].substring(28));
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                }
                                            } else {
                                                if(Integer.parseInt(sep[0]) > 0) {
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    sep[0] = four2Complete(Integer.toBinaryString(nnnn));
                                                    String finalis = (doubleRR(sep[1]) + "0" + sep[0]);
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                } else if(Integer.parseInt(sep[0]) == 0){
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(sep[0])));
                                                    String IDX = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(sep[0])).toUpperCase());
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                }else {
                                                    int nnnn = Integer.parseInt(sep[0]);
                                                    nnnn = Math.abs(nnnn);
                                                    nnnn -= 1;
                                                    nnnn = ~nnnn;
                                                    sep[0] = Integer.toBinaryString(nnnn);
                                                    String finalis = (doubleRR(sep[1]) + "0" + sep[0].substring(27));
                                                    //System.out.println("Hexadecimal: " + Integer.toHexString(Integer.parseInt(finalis,2)));
                                                    String IDX = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(Integer.parseInt(finalis,2)).toUpperCase());
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                }
                                            }
                                        }
                                    }
                                    break;
                                case "IDX1":
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep3[] = opera.split(",");
                                        if(sep3[0].isEmpty())
                                            sep3[0] = "0";
                                        if(Integer.parseInt(sep3[0]) > -16 && Integer.parseInt(sep3[0]) < 17) {}
                                        else{
                                                if(Integer.parseInt(sep3[0]) < 0) {
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep3[0], sep3[0]))).toUpperCase();
                                                    String IDX = ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt("111" + doubleRR(sep3[1]) + "000", 2)).toUpperCase() + temporal.substring(temporal.length()-2);
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                } else if(Integer.parseInt(sep3[0]) > 15 && Integer.parseInt(sep3[0]) < 256){
                                                    String temp = "111" + doubleRR(sep3[1]) + "000";
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep3[0], sep3[0]))).toUpperCase();
                                                    String IDX = ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt(temp,2)).toUpperCase() + temporal.substring(temporal.length()-2);
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                }
                                        }
                                    }
                                    break;
                                case "IDX2":
                                    if(!opera.contains("[") && !opera.contains("]")) {
                                        String sep2[] = opera.split(",");
                                        if(sep2[0].isEmpty())
                                            sep2[0] = "0";
                                        if(Integer.parseInt(sep2[0]) < 65536 && Integer.parseInt(sep2[0]) > 255){
                                                if(Integer.parseInt(sep2[0]) < 0) {
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep2[0], sep2[0]))).toUpperCase();
                                                    String IDX = ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt("111" + doubleRR(sep2[1]) + "010", 2)).toUpperCase() + temporal;
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX);
                                                    S19record(IDX, spaces[1]); // Llamado del S19record
                                                } else {
                                                    String temp = "111" + doubleRR(sep2[1]) + "010";
                                                    String temporal = Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(sep2[0], sep2[0]))).toUpperCase();
                                                    String IDX2 = ar.getTABOP().get(i+3) + Integer.toHexString(Integer.parseInt(temp,2)).toUpperCase() + four2Complete(temporal);
                                                    ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+IDX2);
                                                    S19record(IDX2, spaces[1]); // Llamado del S19record
                                                }
                                        } else {
                                            String IDX = "CODOP: error";
                                            ar.getmCode().add(IDX);
                                        }
                                    }
                                    break;
                                case "[IDX2]":
                                    String sep4[] = opera.substring(1,opera.length()-1).split(",");
                                    
                                    if(Integer.parseInt(sep4[0]) > -1 && Integer.parseInt(sep4[0]) < 65536) {
                                        String IDX2C = "111" + doubleRR(sep4[1])+"011";
                                        ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+ar.getTABOP().get(i+3)+Integer.toHexString(Integer.parseInt(IDX2C,2)).toUpperCase() + four2Complete(Integer.toHexString(Integer.parseInt(sep4[0])).toUpperCase()));
                                        S19record(ar.getTABOP().get(i+3)+Integer.toHexString(Integer.parseInt(IDX2C,2)).toUpperCase() + four2Complete(Integer.toHexString(Integer.parseInt(sep4[0])).toUpperCase()), spaces[1]); // Llamado del S19record
                                    }
                                    break;
                                case "[D,IDX]":
                                    String sep5[] = opera.substring(1,opera.length()-1).split(",");
                                    if(sep5[0].equals("D")) {
                                        String DIDX = "111" + doubleRR(sep5[1])+"111";
                                        ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+ar.getTABOP().get(i+3)+Integer.toHexString(Integer.parseInt(DIDX,2)).toUpperCase());
                                        S19record(ar.getTABOP().get(i+3)+Integer.toHexString(Integer.parseInt(DIDX,2)).toUpperCase(), spaces[1]); // Llamado del S19record
                                    }
                                    break;
                                case "REL": // Caso de los relativos
                                    /* Ciclo for para recorrer y encontrar similitudes
                                    entre los contadores de localidades del tabsim y el temporal*/
                                    for (int j = 0; j < contadorLocalidades.size(); j++) {
                                        if(spaces[4].equals(contadorLocalidades.get(j))) {  // Si es igual
                                            /* Ciclo for para obtener el siguiente contador de localidades
                                            en cuanto respecta al uso de los relativos*/
                                            for (int k = 1; k < breakpoint.size()-1; k++) {
                                                if(spaces[1].equals(breakpoint.get(k))) {   // Si encuentra el mismo contador de localidades
                                                    if(codop.startsWith("L")) { // Caso para los de 16 bits
                                                        int origen = Integer.parseInt(contadorLocalidades.get(j+1), 16), destino = Integer.parseInt(breakpoint.get(k+1), 16);
                                                        System.out.println("punto " + breakpoint.get(k+1));
                                                        int total = origen - destino;
                                                        if(total > -132768 && total < 32767){
                                                            String REL = "";
                                                            if(total < 0) { // Si el valor total es negativo
                                                                REL = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(total).toUpperCase()).substring(4);
                                                                ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+REL);
                                                                S19record(REL, spaces[1]); // Llamado del S19record
                                                            }else {
                                                                REL = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(total).toUpperCase());
                                                                ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+REL);
                                                                S19record(REL, spaces[1]); // Llamado del S19record
                                                            }
                                                        }else {
                                                            ar.getmCode().add("ERROR");
                                                        }
                                                    } else {    // Caso para los de 8 bits
                                                        int origen = Integer.parseInt(contadorLocalidades.get(j+1), 16), destino = Integer.parseInt(breakpoint.get(k+1).substring(2), 16);
                                                        int total = origen - destino;
                                                        if(total > -128 && total < 127){
                                                            String REL = "";
                                                            if(total < 0) { // Si el valor total es negativo
                                                                REL = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(total).toUpperCase()).substring(6);
                                                                ar.getmCode().add("CODOP " + ar.getTABOP().get(i) + " "+REL);   // Adicion del relativo
                                                                S19record(REL, spaces[1]); // Llamado del S19record
                                                            }else {
                                                                REL = ar.getTABOP().get(i+3) + two2Complete(Integer.toHexString(total).toUpperCase());
                                                                ar.getmCode().add("CODOP: "  + ar.getTABOP().get(i) + " " + REL);   // Adicion del relativo
                                                                S19record(REL, spaces[1]); // Llamado del S19record
                                                            }
                                                        } else {
                                                            ar.getmCode().add("CODOP: "  + ar.getTABOP().get(i) + " " + "ERROR");
                                                        }
                                                    }   // Fin de else
                                                }   // Fin de main if
                                            }   // Fin de for                                            
                                        }   // Fin de if
                                    }   // Fin de for
                                    break;
                                default:    // caso default
                                    System.out.println("Missing target!!!");
                                    break;  // Salida del caso
                            }   // Fin de switch
                        }   // Fin de analizador de operando
                        
                    }   // Fin de comparador de tabop
                    
                }   // Fin de for para recorrer tabop
                if (analizadorOperando.constDirect(codop)){ // Caso para los constantes directos
                    switch(codop){  // switch para el codop
                        case "DB":  // Casos de un byte
                        case "DC.B":
                        case"FCB":
                        if(!analizadorOperando.constDirect(codop, opera).equals("-1")){ // Si el valor lo devuelve lo contrario a negativo continuara
                            String constDirec = two2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)))).toUpperCase());    // Llamado de funciones
                            ar.getmCode().add("Codop " + codop + " " +constDirec); // Adicion de codigo maquina
                            S19record(constDirec, spaces[1]); // Llamado del S19record
                        } else  // Si es negativo
                                ar.getmCode().add("Codop " + codop + " Error!!!");  // Error
                            break;
                        case "DW":  // Casos de dos bytes
                        case "DC.W":
                        case "FDB":
                            if(!analizadorOperando.constDirect(codop, opera).equals("-2")){ // Si el valor lo devuelve lo contrario a negativo continuara
                            String constDirec = four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)))).toUpperCase());   // Llamado de funciones
                            ar.getmCode().add("Codop " + codop + " " +constDirec); // Adicion de codigo maquina
                            S19record(constDirec, spaces[1]); // Llamado del S19record
                        } else  // Si es negativo
                                ar.getmCode().add("Codop " + codop + " Error!!!");  // Error
                            break;
                        case "FCC": // Casos de longitud
                            if(!analizadorOperando.constDirect(codop, opera).contains("-")){    // Si el valor lo devuelve lo contrario a negativo continuara
                                String ASCIIcontainer = "";
                                for (int i = 1; i < opera.length()-1; i++) {    // Ciclo for para la acumulacion de ascii
                                    char myChar = opera.charAt(i);  // Variable de uso temporal para los char
                                    ASCIIcontainer += Integer.toString(giveMyASCII(myChar),16).toUpperCase();    // Acumulacion de ascii llamando la funcion
                                }   // Fin de for
                                ar.getmCode().add("Codop " + codop + " " +ASCIIcontainer); // Adicion de codigo maquina
                                S19record(ASCIIcontainer, spaces[1]); // Llamado del S19record
                            }   else  // Si es negativo
                                ar.getmCode().add("Codop " + codop + " Error!!!");  // Error
                            break;
                        default:    // Case default
                            break;
                    }   // Fin de switch de const
                }   // Fin de condicional
                /////////////////////////////////////
                // Espacio para el calculo de S1
                /////////////////////////////////////
                if(codop.equals("ORG")){    // Condicional para calcular el S0
                    this.addressActual = spaces[1];
                    /* Variables */
                    int contadorLong = 0, chsum = 0;
                    ////////////////////////////
                    String ASCIIcontainer = "";
                    for (int i = 8; i < directionTEMP.length(); i++) {    // Ciclo for para la acumulacion de ascii
                        char myChar = directionTEMP.charAt(i);  // Variable de uso temporal para los char
                        ASCIIcontainer += Integer.toString(giveMyASCII(myChar),16).toUpperCase() + " ";    // Acumulacion de ascii llamando la funcion
                    }   // Fin de for
                    String[] S0 = ASCIIcontainer.substring(0,ASCIIcontainer.length()-1).split(" ");
                    contadorLong = S0.length +3;
                    chsum = contadorLong + 00 + 00 ;
                    for (String sum : S0) {
                        chsum += Integer.parseInt(sum, 16);
                    }
                    String temporalis = Integer.toString(chsum);
                    int c1 = Integer.parseInt(Integer.toHexString(Integer.parseInt(temporalis)).substring(temporalis.length()-3).toUpperCase(), 16);    // Conversion y toma de bit menos significativo
                    int process = ~c1;
                    fw.write("S0 " + contadorLong + " 0000 " + ASCIIcontainer.substring(0,ASCIIcontainer.length()-1) + " " + Integer.toHexString(process).substring(6).toUpperCase() + "\n");    // Con el substring se elimina el ultimo espacio
                }
            }   // Fin de else
        }   // Fin de while de lectura del temporal
        inside = false;
        if (inside != true){
            S1calculus();
        }
        fw.write("S9 03 0000 FC");
        fw.close();
        br.close(); // Cierre de temporal
    }   // Fin de metodo
    
/////////////////////////////////////////@@@&&&&&&&&&&&&&&&&&&&@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
////////////////////////////////////////&@&&&&&&&&&&&&&&&&@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////@&&&&&&&&&&&&&&@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
////////////////////////////////////////*@%&&&&&&&&&&&@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
////////////////////////////////////////*@&&&&&&&&&&&@&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////@&&&&&&&&&&%@#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////@@&&&&&&&&&&@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////@@&&&&&&&&&&@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////&@&&&&&&&&&&@@%%%%%%%%@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%&@@&%%%%%%@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////#@&&&&&&&&&&@@%%%%%@%######%@@&#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@@@%(////((&@@@@@&%%%%%%%%%%%@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////(@&&&&&&&&&&&@%%%%@%############@@@@%%%%%%%%%%%%%%%%%%%%%%%&@@&,**********************.@@@@#@@@%#%@@#@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//////////////////////////////////////////@&&&&&&&&&&&@#%%%%@##################%@@@@@@&%&@@@@&#%&@@*********************************,(@@&%%%@@%%%%@@%%%%%%%%%%%%%%%%%%%%%%%%%%%
/////////////////////////////////////////*@&&&&&&&&&&&@%%%%%@@###############################%@@*****************************************%@@@@%%%%%@@%%%%%%%%%%%%%%%%%%%%%%%%%%
//////////////////////////////////////////@@&&&&&&&&&&@&%%%%&@#############################@@**********************************************@@@%%%%%@@%%%%%%%%%%%%%%%%%%%%%%%%%%
//////////////////////////////////////////@@&&&&&&&&&&@&%%%%#@####@@@%##################%@@***********************************************@&**@@#%%@%%%%%%%%%%%%%%%%%%%%%%%%%%%
//////////////////////////////////////////@@&&&&&&&&&&@@%%%%%@%@@%################&@@@%********************************************************,@@@@@@@@@@@@@@@@@@@@@@@@&%%####
//****//////////////////////////////////////&@&&&&&&&&&&@@%%%%%@@#############&@@#    %@@,*******************************************************.@@###########################
//######&@//////////////////////////////////#@&&&&&&&&&&@@%%%@&#############@@            @@(****@@********************************************,@@*%@##########################
//#######(#@*///////////////////////////////*@&&&&&&&&&&%@%@%##############@(    .@@(        &@@*(@@@@@@@@@@@@@@@@/,***************************(***,@##########################
//&&@@(#####@///////////////////////////////*@&&&&&&&&&&&@@################@*                 .@@                   &@@,***************************,@%#########################
//&&&&&@&###&%///////////////////////////////@&&&&&&&&&@@##################@@   %@@#*#&@@@   @@         (@@          @*****************************,@@@@&(#####################
//(@@&&&&@(#@////////////////////////////////@@&&&&&&@@######################@@@%**********@@@                       @(*****************************@##########################
//(@@&&&@@(////////////////////////////////@@&&&&&@@#####################@@**,@%***********@                       @,****************************%@(@@@@@@%####################
/////@&&&@/////////////////////////////*/&@@@@@@@@@@@@@@@@@@@@@@@@@@%##%@%%%%%%(@@,********,@#                    @%***************************#@@&############################
//////@&&&@///////////////////////@@@@@&(###########################(&@@@@@@&,****,,%@@@&,***,@@                @@,************************#@@#%###############################
//////@&&&@%/////////////////&@@@%############################################@@@@@@/,***,#@@***,&@@&#.  .#@@@@*****************,#%,***,@@%####################################
///////@&&&@//////////////@@@%######################################################(&@@@@(,*,@@,***************************(@@%,,@**@@#%######################################
///////@&&@@@@@@@@@@@@@@@@@@@@@@@@@@&%#####################################################@@@@&/@(*********************,@@(*****/@@&#%########################################
//@@@@@@@&#(((((((((((((((((((((((((((((#&@@@@@@&################################################(@@@@*****************************@@##########################################
//(((((((((((((((((((((((((((((((((((((((((((((((%@@@@%###############################################&@@&,**********************@@@%##%#######################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((#@@@&##############################################%@@@***************@@@@@@#############################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((((((#@@@(#############################################@@@(*******(@@,*,,&@&##############################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((@@@##############################################@@@*******#@@&##################################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((%@@###############################################@@@,*@@######################################################
//(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((@@################################################@@@#######################################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((@@@################################################(@@@####################################################
//((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((@@###################################################@@@#################################%@@@@@@@@@@@&&&&
    /**
     * Metodo para poder hacer el llenado adecuado del S record
     * para los casos de S1
     * @param machineCode   -Codigo maquina a insertar para el S1
     * @param actualAddress     - Dar direccion actual para calcular si esta excede o no
     * @param codop     -Codop solo para ser usado como identificador del ORG
     * @param directionTEMP -Parametro solo para cargar el nombre inicial de S0
     */
    private void S19record(String machineCode, String actualAddress) throws IOException {
        /* Creacion de objetos */
        // Creacion de variables
        int conta = 0;
        ///////////////////////////        
        if(this.estoNoEsUnContador <= 19) {
            if(machineCode.length()%2 == 0) {
                for (int i = 0; i < machineCode.length(); i+=2) {
                    this.estoNoEsUnContador++;
                    conta+=2;
                    this.longitud += machineCode.substring(i,conta) + " ";
                    this.checkSum += Integer.parseInt(machineCode.substring(i,conta), 16);
                    System.out.println("checksum " + (machineCode.substring(i,conta)));
                    checador(this.estoNoEsUnContador, actualAddress);
                }
            } else {
                String newMachineCode = machineCode.substring(0,machineCode.length()-1) + "0" + machineCode.substring(machineCode.length()-1);
                for (int i = 0; i < newMachineCode.length(); i+=2) {
                    this.estoNoEsUnContador++;
                    conta+=2;
                    this.longitud += newMachineCode.substring(i,conta) + " ";
                    this.checkSum += Integer.parseInt(newMachineCode.substring(i,conta), 16);
                    System.out.println("checksum " + (newMachineCode.substring(i,conta)));
                    checador(this.estoNoEsUnContador, actualAddress);
                }
            }
        } else {
            this.addressActual = actualAddress;
            this.estoNoEsUnContador = 3;
        }
        //System.out.println("Contador: " + this.estoNoEsUnContador);
    }   // Fin de metodo
    /**
     * Metodo creado para revisar cuando las condiciones se exceden
     * reinicie las condicionales y variables para la ejecucion
     * @param counter -
    */
    private void checador(int counter, String direccion) throws IOException {
        if(counter == 19) {
            S1calculus();
            this.addressActual = direccion;
            this.estoNoEsUnContador = 3;
            this.longitud = "";
            this.checkSum = 0;
        }
    }
    
    private void S1calculus() throws IOException {
        if(this.estoNoEsUnContador < 20) {
            String prueba = Integer.toHexString(this.checkSum);
            //System.out.println("Direccion " + Integer.parseInt(this.addressActual.substring(0,this.addressActual.length()-2), 16) + " " + Integer.parseInt(this.addressActual.substring(this.addressActual.length()-2), 16));
            //System.out.println("Puebame " + this.checkSum + " "+ Integer.parseInt(Integer.toString(this.estoNoEsUnContador),16)+" " + Integer.parseInt(this.addressActual, 16));
            this.checkSum += this.estoNoEsUnContador + Integer.parseInt(this.addressActual.substring(0,this.addressActual.length()-2), 16) + Integer.parseInt(this.addressActual.substring(this.addressActual.length()-2), 16);
            int pasadena = ~(this.checkSum);
            System.out.println("Pasantia " + Integer.toHexString(pasadena).substring(6).toUpperCase());
            fw.write("S1 " + this.estoNoEsUnContador + " " + this.addressActual + " " + this.longitud + " " + Integer.toHexString(pasadena).substring(6).toUpperCase() + "\n");
        }
    }
    
    
    
    /**
     * Metodo para retornar los valores en ascii de cada caracter
     * que se le de.
     * @param cadena -Cadena de ingreso para ser transformada en char
     * @return -Retorna el valor de la letra del String en ASCII
     */
    private int giveMyASCII(char cadena){
        return (int) cadena;
    }
    
    /**
     * Metodo para cargar el tabsim
     * @param directionTABSIM -Da el valor de la url del tabsim
     */
    private void chargeMyTabSim(String directionTABSIM) throws FileNotFoundException, IOException{
        /** Creacion de objetos */
        arrayContainer ar = new arrayContainer();
        //////////////////////////////////////////
        FileReader frTABSIMrel = new FileReader(directionTABSIM);
        BufferedReader brTABSIMrel = new BufferedReader(frTABSIMrel);
        //////////////////////////////////////////////////////
        // Variables
        String tbr = "";
        ///////////////////////////////////////////////////////
        while((tbr = brTABSIMrel.readLine()) != null ) {   // Ciclo while para recorrer las partes del TABSIM
            String[] contLocFollower;
            if(tbr.equals("TABSIM no generado :)")){
                break;
            } else {
                contLocFollower = tbr.split("\t");
                String etiqueta = contLocFollower[1], contadorLoc = contLocFollower[2];
                this.contadorLocalidades.add(etiqueta);
                this.contadorLocalidades.add(contadorLoc);
            }
        }   // Fin de while de cargador
        brTABSIMrel.close();
    }   // Fin de metodo
    
    /***/
    private void chargeTEMP(String directionTEMP) throws FileNotFoundException, IOException{
        /** Creacion de objetos */
        FileReader fr = new FileReader(directionTEMP);
        BufferedReader br = new BufferedReader(fr);
        //////////////////////////////////////////
        //Variables
        String reader = "";
        while((reader = br.readLine())!=null){  // ciclo while para analizar las lines del temporal
            //Variables
            String spaces[] = reader.split("\t");   // Separacion por tabuladores de las distintas secciones
            //////////////////////////////////////////////////
            if(spaces.length > 2) {
                if(!spaces[3].equals("EQU")) {
                    this.breakpoint.add(spaces[1]);
                }
            }   // Fin de if
        }   // FIn de while
        br.close(); // Cierre de archivo
    }
    
     /**
     * Funcion para retornar la cadena en formato de 
     * 4 digitos.
     * @param chain -Cadena de ingresio para dar la cantidad de 0 faltantes
     */
    private String four2Complete(String chain){
        String concat = ""; // Auxiliar de concatenacion de 0
        if(chain.length() < 5) {    // Si la cadena es menor que 4 digitos
            for (int i = chain.length(); i < 4; i++)  // For que empieza por la cantidad de caracteres de la cadena y termina cuando cumple el 4to
                concat += "0";  // Aumento de concatenacion
            return concat + chain;  // Devuelve el valor de la cadena final
        } else
            return chain;   // Si ya lo tiene solo devuelve el valor como tal
    }   // Fin de funcion
    /**
     * Funcion para retornar para cuando los valores sean menores a 5 bits
     * y de esta forma retorne el valor en un fomato de 4 digitos
     * @param chain -Cadena de entrada del texto
     */
    private String two2Complete(String chain) {
        String concat = ""; // Variable axuliar
        if(chain .length() < 2) {   // Si es menor a 2
            for (int i = chain.length(); i < 2; i++)    // Reccore y concatena
                concat += "0";
            return concat + chain;  // Devuelve el nuevo valor
        } else  // Si no es
            return chain;   // Lo devuelve igual
    }   // Fin de metodo
    /**
     * Funcion para retornar el valor de el acumulador depndiendo el tipo de este
     * retorna el valor de el acumuldar dentro de la formula
     * @param rr Parte de la formula(acumulador)
     */
    private static String doubleRR(String rr) {
        String temporal = "";
        if(rr.contains("+") || rr.contains("-")) {  // Si contiene un simbolo
            String separator[] = rr.split("\\+|\\-");   // Separa los posibles acumuladores
            for (String string : separator) {   // For iterado
                if(string.equals("X") || string.equals("Y") || string.equals("PC") || string.equals("SP")) {    // Si es algun acumulador
                    temporal = string;  // Guarda el acumulador
                    break;  // Sale
                } else  // Error
                    temporal = "Error!";
            }   // Fin de for
        } else  // Si no tiene simbolos
            temporal = rr;  // Asignacion de temporal
        switch(temporal){
            case "X":
                return "00";
            case "Y":
                return "01";
            case "SP":
                return "10";
            case "PC":
                return "11";
            default:
                return "ERROR";
        }   // Fin de switch
    }   // Fin de funcion
    /**
     * Funcion para retornar el valor de p dentro de la funcion
     * @param registro -Registro que se usara para obtener el tipo de pre o post
     */
    private static String pPosition(String registro) {
        if(registro.startsWith("+") || registro.startsWith("-"))    // Si es pre
            return "0";
        else if(registro.endsWith("+") || registro.endsWith("-"))   // Si es post
            return "1";
        else
            return "Error pPosition"; // Missing case
    }   // Fin de funcion
    /**
     * Funcion para retornar el valor de un acumulador especifico
     * @param acum -Variable acumulador a cargar para retornar valor
     */
    private static String aPosition(String acum) {
        switch(acum) {  // Switch para cada funcion
            case "A":
                return "00";
            case "B":
                return "01";
            case "D":
                return "10";
            default:
                return "Error a position";
        }   // Fin de switch
    }   // Fin de la funcion
    
}   // Fin de clase
