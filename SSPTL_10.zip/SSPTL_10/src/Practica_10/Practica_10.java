/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica_10;

import Tools.Identificador;
import Tools.arrayContainer;
import Tools.contLoc;
import Tools.machineCode;
import java.io.IOException;

/**
 *
 * @author José David Delgado Ramírez
 */
public class Practica_10 {
    public static void main(String[] args) throws IOException{
        /**
         * Creacion de objetos
         */
        arrayContainer ar = new arrayContainer();
        Identificador id = new Identificador();
        contLoc cl = new contLoc();
        machineCode mc = new machineCode();
        
        id.runner("src/TXT/prueba 5.txt", "src/TXT/tabop.txt");    // Carga de metodo de precarga a la comparacion
        ar.finder();    // Llamado al metodo de comparacion
        cl.contadorLocal();
        mc.machineCodeCalculator("src/TXT/temporal.txt", "src/txt/TABSIM.txt");
        // Ciclo for para recorrer el resultado final de la comparacion
        /*for (int i = 0; i < ar.getRESULT().size(); i++) {
            System.out.println(ar.getRESULT().get(i));
        }*/
        for (int i = 0; i < ar.getINST().size(); i++) {
            System.out.println(ar.getINST().get(i));
        }
        System.out.println("Paso de codigo maquina!!!");
        for (int i = 0; i < ar.getmCode().size(); i++) {
            System.out.println(ar.getmCode().get(i));
        }
        
    }   // Fin de main
}
