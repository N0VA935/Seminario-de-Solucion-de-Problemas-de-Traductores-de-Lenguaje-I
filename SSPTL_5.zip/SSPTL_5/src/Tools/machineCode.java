
package Tools;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author José David Delgado Ramírez
 */
public class machineCode{
    public void machineCodeCalculator(String directionTEMP, String directionTABSIM) throws FileNotFoundException,IOException{
        /** Creacion de objetos */
        FileReader fr = new FileReader(directionTEMP);
        BufferedReader br = new BufferedReader(fr);
        arrayContainer ar = new arrayContainer();
        analizadorOperando ap = new analizadorOperando();
        //////////////////////////////////////////
        //Variables
        String reader = "";
        while((reader = br.readLine())!=null){  // ciclo while para analizar las lines del temporal
            String spaces[] = reader.split("\t");   // Separacion por tabuladores de las distintas secciones
            if(spaces[2].equals("END")) {   // si se llega al END
                System.out.println(spaces[2]);  // Impresion del final
            } else {    // TODO CODE HERE
                String ContLoc = spaces[1], Etq = spaces[2], codop = spaces[3], opera = spaces[4];  // Distintas variables para la separacion de las partes del temporal
                for (int i = 0; i < ar.getTABOP().size(); i+=6) {   // Ciclo for para recorrer el for precargado
                    if(codop.equals(ar.getTABOP().get(i))) {    // Si se encuentra el CODOP dentro del for
                        if(analizadorOperando.opChecker(i+2, opera) != false) { // Condicional para verificar que cumpe los aspectos dependiendo del tipo que es
                            switch(ar.getTABOP().get(i+2)) {    // Switch para cada caso
                                case "Inherente ":  // Caso de Inherentes
                                    String INH = "CODOP: " + ar.getTABOP().get(i) + " " + ar.getTABOP().get(i+3); // Obtencion del codigo maquina
                                    ar.getmCode().add(INH); // Append del codigo maquina en el arraylist 
                                    break;  // Salida
                                case "Directo": // Caso directo
                                    String DIR = "CODOP: " + ar.getTABOP().get(i) + ar.getTABOP().get(i+3) + analizadorOperando.baseToDecimal(opera.substring(1), opera.substring(0,1));    // Obtencion del codigo maquina
                                    ar.getmCode().add(DIR); // Append del codigo maquina
                                    break;  // Salida del caso
                                case "Extendido":   // Caso extendido
                                    /** Creacion de objetos para el TABSIM */
                                    FileReader frTABSIM = new FileReader(directionTABSIM);
                                    BufferedReader brTABSIM = new BufferedReader(frTABSIM);
                                    ///////////////////////////////////////////////////////
                                    // Variables
                                    String tabsimReader = "";
                                    while((tabsimReader = brTABSIM.readLine()) != null) {   // Ciclo while para recorrer las partes del TABSIM
                                        String tabsimSpaces[] = tabsimReader.split("\t");   // Separacion mediante tabuladores
                                        String tipo = tabsimSpaces[0], etqTabsim = tabsimSpaces[1], conlocTabsim = tabsimSpaces[2]; // Variables de las partes del TABSIM
                                        if(etqTabsim.equals(opera)) {    // Si el operando es igual a un elemento del tabsim
                                            String EXT = ar.getTABOP().get(i+3) + conlocTabsim; // Valor del codigo maquina segun el COntloc
                                            ar.getmCode().add(EXT); // Append del codigo maquina
                                        }else { // Si no lo es
                                            String EXT = ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(0), opera.substring(0,1)))).toUpperCase());   // Obtencion del codigo maquina
                                            ar.getmCode().add(EXT); // Append del codigo maquina
                                        }
                                    }   // Fin de while
                                    brTABSIM.close();   // Cierre de TABSIM
                                    break;  // Salida del caso
                                case "Inmediato":   // Caso Inmediato
                                    String INM = "CODOP: " + ar.getTABOP().get(i) + ar.getTABOP().get(i+3) + four2Complete(Integer.toHexString(Integer.parseInt(analizadorOperando.baseToDecimal(opera.substring(1), opera.substring(1,2)))).toUpperCase());    // Obtencion del codigo maquina
                                    ar.getmCode().add(INM); // Append del codigo maquina
                                    break;  // Salida del caso
                                default:    // caso default
                                    System.out.println("Missing target!!!");
                                    break;  // Salida del caso
                            }   // Fin de switch
                        }   // Fin de analizador de operando
                        break;  // Cierre de condicional para la comparacion!!!
                    }   // Fin de comparador de tabop
                }   // Fin de for para recorrer tabop
            }   // Fin de else
        }   // Fin de while de lectura del temporal
        br.close(); // Cierre de temporal
    }   // Fin de metodo
     /**
     * Funcion para retornar la cadena en formato de 
     * 4 digitos.
     * @param chain -Cadena de ingresio para dar la cantidad de 0 faltantes
     */
    private String four2Complete(String chain){
        String concat = ""; // Auxiliar de concatenacion de 0
        if(chain.length() < 5) {    // Si la cadena es menor que 4 digitos
            for (int i = chain.length(); i < 4; i++)  // For que empieza por la cantidad de caracteres de la cadena y termina cuando cumple el 4to
                concat += "0";  // Aumento de concatenacion
            return concat + chain;  // Devuelve el valor de la cadena final
        } else
            return chain;   // Si ya lo tiene solo devuelve el valor como tal
    }   // Fin de funcion
}   // Fin de clase
