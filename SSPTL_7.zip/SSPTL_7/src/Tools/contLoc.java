/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tools;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.Iterator;
/**
 *
 * @author José David Delgado Ramírez
 */
public class contLoc {
    Contador cont = new Contador(); // Contador para las localidades
    public void contadorLocal() throws IOException{
        FileWriter fw = new FileWriter("src/TXT/temporal.txt"); // FW para el temporal
        FileWriter fwTAB = new FileWriter("src/TXT/TABSIM.txt");    // FW para tabla de simbolos
        arrayContainer ar = new arrayContainer();   // Objeto del contenedor
        Iterator it = ar.getIMPBYTES().iterator();  // Iterador para recorrer
        Formatter dig = new Formatter();
        boolean tabsimPass = false; // Boleano para la tabla de simbolos para cuando no encuentra etiquetas para la tabSIM
        
        while(it.hasNext()) {   // Mientras tenga un elemento
            String carga = (String) it.next();  // Carga de elementos de forma temporal
            if(carga.startsWith("~")){  // Para el inicio de ORG
                String[] temporal = carga.split("~|\\°");    // Separacion de los caracteres de ORG y los del principal
                cont.setCount(Integer.parseInt(temporal[1]));    // Dar el valor inicial al contador de localidades
                fw.write("DIR_INIC\t" + four2Complete(Integer.toHexString(cont.showCount()).toUpperCase()) + "\t" + temporal[2] + "\t" + temporal[3] + "\t" +temporal[4] + "\n");
            } else if(carga.startsWith("&")) {  // Condicional para los CODOP y directivas
                String[] temporal = carga.split("&|\\°");
                fw.write("CONTLOC\t" + four2Complete(Integer.toHexString(cont.showCount()).toUpperCase()) + "\t" + temporal[2] + "\t" + temporal[3] + "\t" +temporal[4] + "\n");
                cont.addCount(Integer.parseInt(temporal[1]));
            }
            else if(carga.startsWith("¨") && carga.contains("^")) {  // Si contiene una etiqueta y tiene el simbolo de EQU
                String[] temporal = carga.split("¨|\\^|\\°");
                if(!temporal[2].isEmpty()) {
                    tabsimPass = true;  // Lo registra como true
                    fwTAB.write("EQU_(ETIQUETA_ABSOLUTA)\t" + temporal[3] + "\t" + four2Complete(Integer.toHexString(Integer.parseInt(temporal[1])).toUpperCase()) + "\n");
                    fw.write("VALOR_EQU\t" + four2Complete(Integer.toHexString(Integer.parseInt(temporal[1])).toUpperCase()) + "\t" + temporal[3] + "\t" + temporal[4] + "\t" +temporal[5] + "\n");
                    cont.skipCount(Integer.parseInt(temporal[2]));
                }
            } else if(carga.startsWith("¨") && carga.contains("&")) {  // Si contiene una etiqueta y tiene el simbolo de CODOP
                String[] temporal = carga.split("¨|\\&|\\°");
                if(!temporal[2].isEmpty()) {
                    tabsimPass = true;  // Lo registra como true
                    fwTAB.write("CONLOC_(ETIQUETA_RELATIVA)\t" + temporal[3] + "\t" + four2Complete(Integer.toHexString(cont.showCount()).toUpperCase()) + "\n");
                    fw.write("CONTLOC\t" + four2Complete(Integer.toHexString(cont.showCount()).toUpperCase()) + "\t" + temporal[3] + "\t" + temporal[4] + "\t" +temporal[5] + "\n");
                    cont.addCount(Integer.parseInt(temporal[2]));
                }
            } else
                tabsimPass = false; // Cuando no encuentra ninguna etiqueta por cada instruccion
        }
        fw.write("CONTLOC\t" + four2Complete(Integer.toHexString(cont.showCount()).toUpperCase()) + "\tEND");
        fw.close();
        if(!tabsimPass){
            fwTAB.write("TABSIM no generado :) \n");
            fwTAB.close();
        } else {
            fwTAB.close();
        }
    }
    /**
     * Funcion para retornar la cadena en formato de 
     * 4 digitos.
     * @param chain -Cadena de ingresio para dar la cantidad de 0 faltantes
     */
    private String four2Complete(String chain){
        String concat = ""; // Auxiliar de concatenacion de 0
        if(chain.length() < 5) {    // Si la cadena es menor que 4 digitos
            for (int i = chain.length(); i < 4; i++)  // For que empieza por la cantidad de caracteres de la cadena y termina cuando cumple el 4to
                concat += "0";  // Aumento de concatenacion
            return concat + chain;  // Devuelve el valor de la cadena final
        } else
            return chain;   // Si ya lo tiene solo devuelve el valor como tal
    }   // Fin de funcion
        
}